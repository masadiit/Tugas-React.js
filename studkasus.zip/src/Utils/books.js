const books = [
  {
    id: 1,
    title: "Belajar JavaScript Dasar",
    author: "Andi Prasetyo",
    year: 2021,
    description: "Panduan lengkap untuk pemula yang ingin belajar JavaScript dari nol.",
    image: "https://placehold.co/300x200/50D1F3/ffffff?text=JS+DASAR"
  },
  {
    id: 2,
    title: "React untuk Pemula",
    author: "Dina Sari",
    year: 2022,
    description: "Mengenal konsep dan praktik membuat aplikasi React modern.",
    image: "https://placehold.co/300x200/61DAFB/000000?text=REACT+PEMULA"
  },
  {
    id: 3,
    title: "Node.js dan Express: Backend",
    author: "Budi Santoso",
    year: 2020,
    description: "Membangun API RESTful dengan Node.js dan Express.",
    image: "https://placehold.co/300x200/8CC84B/000000?text=NODEJS"
  },
  {
    id: 4,
    title: "Memahami Redux Sederhana",
    author: "Citra Dewi",
    year: 2023,
    description: "Manajemen state yang efisien untuk aplikasi React.",
    image: "https://placehold.co/300x200/764ABC/ffffff?text=REDUX"
  },
  {
    id: 5,
    title: "Panduan CSS Flexbox & Grid",
    author: "Eko Kurniawan",
    year: 2019,
    description: "Menguasai layout modern menggunakan Flexbox dan CSS Grid.",
    image: "https://placehold.co/300x200/FF5733/ffffff?text=CSS+LAYOUT"
  },
  {
    id: 6,
    title: "Python untuk Data Science",
    author: "Ferry Halim",
    year: 2023,
    description: "Pengenalan Python dan library untuk analisis data.",
    image: "https://placehold.co/300x200/3776AB/ffffff?text=PYTHON+DATA"
  },
  {
    id: 7,
    title: "Keamanan Web Aplikasi",
    author: "Gita Puspita",
    year: 2021,
    description: "Melindungi aplikasi web dari berbagai serangan siber.",
    image: "https://placehold.co/300x200/505050/ffffff?text=WEB+SECURITY"
  },
  {
    id: 8,
    title: "TypeScript untuk Skala Besar",
    author: "Hendra Wijaya",
    year: 2024,
    description: "Meningkatkan kualitas kode dengan penggunaan TypeScript.",
    image: "https://placehold.co/300x200/007ACC/ffffff?text=TYPESCRIPT"
  },
  {
    id: 9,
    title: "Desain UI/UX Fundamental",
    author: "Indra Lukmana",
    year: 2018,
    description: "Prinsip dasar mendesain antarmuka pengguna yang efektif.",
    image: "https://placehold.co/300x200/F0E68C/000000?text=UI%2FUX"
  },

  {
    id: 10,
    title: "Clean Code Handbook",
    author: "Robert C. Martin",
    year: 2008,
    description: "Panduan untuk menulis kode yang bersih, mudah dibaca, dan mudah dipelihara.",
    image: "https://placehold.co/300x200/000000/ffffff?text=CLEAN+CODE"
  },
];

export default books;