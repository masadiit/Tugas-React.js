import { BrowserRouter, Route, Routes } from "react-router";

import Home from './pages';
import Books from './pages/books';
import Tim from "./pages/Team";
import Kontak from "./pages/Contact";

function App() {
  return (
    <>
      <div className="container">
        <BrowserRouter>
          <Routes>
            <Route index element={<Home />} />
            <Route path="Books" element={<Books/>} />
            <Route path="Team" element={<Tim/>} />
            <Route path="Contact" element={<Kontak/>} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
