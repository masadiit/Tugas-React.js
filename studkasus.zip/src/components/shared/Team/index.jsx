export default function Team() {
  return (
    <>
      <div className="container px-4 py-5" id="featured-team">
        <h2 className="pb-2 border-bottom text-center">🤝 Tim Kami</h2>

        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 py-5">
          <div className="col d-flex align-items-start">
            <i className="fa-solid fa-crown fs-2 text-primary me-3"></i>
            <div>
              <h3 className="fw-bold mb-0 fs-4 text-body-emphasis">
                Abdur Rohman Lathif
              </h3>
              <p>
                <strong>Founder & CEO</strong>. Memimpin visi dan strategi
                bisnis bookstore.
              </p>
            </div>
          </div>
          <div className="col d-flex align-items-start">
            <i className="fa-solid fa-chart-line fs-2 text-primary me-3"></i>
            <div>
              <h3 className="fw-bold mb-0 fs-4 text-body-emphasis">
                Elok Faiqoh
              </h3>
              <p>
                <strong>Marketing Head</strong>. Bertanggung jawab atas semua
                kampanye pemasaran dan promosi.
              </p>
            </div>
          </div>
          <div className="col d-flex align-items-start">
            <i className="fa-solid fa-code fs-2 text-primary me-3"></i>
            <div>
              <h3 className="fw-bold mb-0 fs-4 text-body-emphasis">
                Bima Harinta
              </h3>
              <p>
                <strong>Lead Developer</strong>. Mengawasi pengembangan dan
                pemeliharaan platform digital kami.
              </p>
            </div>
          </div>
          <div className="col d-flex align-items-start">
            <i className="fa-solid fa-book-reader fs-2 text-primary me-3"></i>
            <div>
              <h3 className="fw-bold mb-0 fs-4 text-body-emphasis">
                Firza Herfian
              </h3>
              <p>
                <strong>Content Curator</strong>. Memilih dan memastikan koleksi
                buku kami selalu relevan.
              </p>
            </div>
          </div>
          <div className="col d-flex align-items-start">
            <i className="fa-solid fa-handshake fs-2 text-primary me-3"></i>
            <div>
              <h3 className="fw-bold mb-0 fs-4 text-body-emphasis">
                Maulana Ardhiansyah P
              </h3>
              <p>
                <strong>Partnership Manager</strong>. Menjalin kerjasama dengan
                penerbit dan distributor.
              </p>
            </div>
          </div>
          <div className="col d-flex align-items-start">
            <i className="fa-solid fa-headset fs-2 text-primary me-3"></i>
            <div>
              <h3 className="fw-bold mb-0 fs-4 text-body-emphasis">
                Muhammad Danil Ma'ruf
              </h3>
              <p>
                <strong>Customer Support</strong>. Siap membantu dan memastikan
                kepuasan pelanggan.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
