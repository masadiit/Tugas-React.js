import React from 'react';

const BookCard = ({ book }) => {
  return (
    <div className="col">
      <div className="card shadow-sm h-100 border-0 rounded-lg">
        <img
          src={book.image}
          className="card-img-top"
          alt={book.title}
          width="100%" 
          height="225" 
          style={{ objectFit: 'cover', borderBottom: '1px solid #eee' }}
        />
        <div className="card-body d-flex flex-column">
          <h5 className="card-title fw-bold text-dark">{book.title}</h5>
          <p className="card-text text-muted small mb-2">Oleh: {book.author}, {book.year}</p>
          <p className="card-text flex-grow-1">
            {book.description.substring(0, 80)}...
          </p>
          <div className="d-flex justify-content-between align-items-center pt-2 border-top">
            <div className="btn-group">
              <button 
                type="button" 
                className="btn btn-sm btn-outline-info text-info me-1"
                onClick={() => alert(`Lihat Detail untuk: ${book.title}`)} 
              >
                Lihat Detail
              </button>
              <button 
                type="button" 
                className="btn btn-sm btn-success"
                onClick={() => alert(`Anda perlu Login untuk membeli ${book.title}`)}
              >
                Beli
              </button>
            </div>
            <small className="text-success fw-bold">Rp 90.000</small>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookCard;