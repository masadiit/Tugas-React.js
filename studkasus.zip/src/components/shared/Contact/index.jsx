export default function Contact() {
  return (
    <>
      <div className="container col-xl-10 col-xxl-8 px-4 py-5">
        <div className="row align-items-center g-lg-5 py-5">
          {/* Kolom kiri - Teks dan tombol kontak langsung */}
          <div className="col-lg-7 text-center text-lg-start">
            <h1 className="display-4 fw-bold lh-1 text-body-emphasis mb-3">
              Hubungi Kami
            </h1>
            <p className="col-lg-10 fs-4">
              Punya pertanyaan, kritik, atau saran untuk koleksi buku kami?
              Jangan ragu untuk menghubungi tim kami melalui formulir kontak di
              samping atau saluran langsung di bawah ini. Kami senang mendengar
              dari Anda!
            </p>
            <div className="d-flex flex-column flex-md-row gap-3 mt-5 justify-content-lg-start justify-content-center">
              <a
                href="https://wa.me/6285708648766"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-success btn-lg d-flex align-items-center justify-content-center"
              >
                <i className="fa-brands fa-whatsapp me-2"></i> WhatsApp
              </a>
              <a
                href="mailto:contact@bookstore.com"
                className="btn btn-danger btn-lg d-flex align-items-center justify-content-center"
              >
                <i className="fa-solid fa-envelope me-2"></i> Email
              </a>
            </div>
          </div>

          {/* Kolom kanan - Formulir Kontak */}
          <div className="col-md-10 mx-auto col-lg-5">
            <form className="p-4 p-md-5 border rounded-3 bg-body-tertiary">
              <h4 className="mb-4 text-center">Kirim Pesan Cepat</h4>
              <div className="form-floating mb-3">
                <input
                  type="text"
                  className="form-control"
                  id="floatingName"
                  placeholder="Nama Lengkap"
                />
                <label htmlFor="floatingName">Nama Lengkap</label>
              </div>
              <div className="form-floating mb-3">
                <input
                  type="email"
                  className="form-control"
                  id="floatingInput"
                  placeholder="name@example.com"
                />
                <label htmlFor="floatingInput">Alamat Email</label>
              </div>
              <div className="form-floating mb-3">
                <textarea
                  className="form-control"
                  id="floatingTextarea"
                  placeholder="Pesan Anda"
                  style={{ height: "150px" }}
                ></textarea>
                <label htmlFor="floatingTextarea">Pesan</label>
              </div>
              <button className="w-100 btn btn-lg btn-primary" type="submit">
                Kirim Pesan
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
