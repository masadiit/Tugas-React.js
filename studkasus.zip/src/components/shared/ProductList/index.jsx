export default function ProductList() {
  return (
    <>
      <section className="py-5 text-center container">
        <div className="row py-lg-5">
          <div className="col-lg-6 col-md-8 mx-auto">
            <h1 className="fw-light">Best Seller</h1>
            <p className="lead text-body-secondary">
              Koleksi buku terlaris pilihan pembaca. Temukan bacaan menarik yang
              akan memperluas wawasan dan inspirasimu.
            </p>
            <p>
              <a href="#" className="btn btn-primary my-2 m-2">
                Lihat Semua
              </a>
              <a href="#" className="btn btn-secondary my-2">
                Buku Lain
              </a>
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
