export default function Album() {
  return (
    <>
      <div className="album py-5 bg-body-tertiary">
        <div className="container">
          <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            {/* Card 1 - 12 (TIDAK DIUBAH) */}
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=1"
                  className="card-img-top"
                  alt="Atomic Habits"
                />
                <div className="card-body">
                  <p className="card-text">
                    Atomic Habits – Cara membangun kebiasaan baik dan
                    menghilangkan kebiasaan buruk.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 95.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=2"
                  className="card-img-top"
                  alt="Rich Dad Poor Dad"
                />
                <div className="card-body">
                  <p className="card-text">
                    Rich Dad Poor Dad – Pelajaran finansial untuk membangun masa
                    depan lebih baik.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 80.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=3"
                  className="card-img-top"
                  alt="The Psychology of Money"
                />
                <div className="card-body">
                  <p className="card-text">
                    The Psychology of Money – Belajar memahami perilaku manusia
                    terhadap uang.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 100.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=4"
                  className="card-img-top"
                  alt="Laskar Pelangi"
                />
                <div className="card-body">
                  <p className="card-text">
                    Laskar Pelangi – Kisah inspiratif anak-anak Belitung dalam
                    meraih mimpi.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 70.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=5"
                  className="card-img-top"
                  alt="Filosofi Kopi"
                />
                <div className="card-body">
                  <p className="card-text">
                    Filosofi Kopi – Kumpulan cerita dan makna dari secangkir
                    kopi.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 60.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=6"
                  className="card-img-top"
                  alt="Sapiens"
                />
                <div className="card-body">
                  <p className="card-text">
                    Sapiens – Sejarah singkat umat manusia dari zaman purba
                    hingga modern.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 120.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=7"
                  className="card-img-top"
                  alt="Ikigai"
                />
                <div className="card-body">
                  <p className="card-text">
                    Ikigai – Rahasia panjang umur dan bahagia dari masyarakat
                    Jepang.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 85.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=8"
                  className="card-img-top"
                  alt="Norwegian Wood"
                />
                <div className="card-body">
                  <p className="card-text">
                    Norwegian Wood – Novel klasik Haruki Murakami tentang cinta
                    dan kehilangan.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 95.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=9"
                  className="card-img-top"
                  alt="Thinking, Fast and Slow"
                />
                <div className="card-body">
                  <p className="card-text">
                    Thinking, Fast and Slow – Bagaimana otak bekerja dalam
                    pengambilan keputusan.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 110.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=10"
                  className="card-img-top"
                  alt="Negeri 5 Menara"
                />
                <div className="card-body">
                  <p className="card-text">
                    Negeri 5 Menara – Kisah inspiratif tentang pendidikan dan
                    perjuangan.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 75.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=11"
                  className="card-img-top"
                  alt="The Subtle Art of Not Giving a F*ck"
                />
                <div className="card-body">
                  <p className="card-text">
                    Filosofi Teras – Mengupas filsafat kuno untuk mengatasi
                    emosi negatif.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 90.000</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="card shadow-sm">
                <img
                  src="https://picsum.photos/300/200?random=12"
                  className="card-img-top"
                  alt="Dilan 1990"
                />
                <div className="card-body">
                  <p className="card-text">
                    Dilan 1990 – Kisah cinta remaja Bandung yang penuh
                    nostalgia.
                  </p>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="btn-group">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Beli
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                      >
                        Detail
                      </button>
                    </div>
                    <small className="text-body-secondary">Rp 65.000</small>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
