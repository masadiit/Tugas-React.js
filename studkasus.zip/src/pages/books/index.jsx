// src/pages/books/index.jsx

import React, { useState } from 'react'; 
import Header from "../../components/shared/Header";
import Footer from "../../components/shared/Footer";
import initialBooks from '../../Utils/books'; 
import BookCard from '../../components/shared/BookCard'; 

export default function Books () {
    const [bookList, setBookList] = useState(initialBooks);

    const addBook = () => {
        const newId = Date.now();
        const newBook = {
            id: newId,
            title: `Buku Baru Tambahan (${newId % 100})`, 
            author: "Admin Books",
            year: new Date().getFullYear(),
            description: "Data ini ditambahkan dari Halaman Books menggunakan Hooks.",
            image: `https://placehold.co/300x200/FF8C00/ffffff?text=NEW+BOOK+${newId % 100}`
        };
        setBookList([newBook, ...bookList]);
    };

    return (
        <>
            <Header/>
            
            <section className="py-5 text-center container">
                <div className="row py-lg-5">
                    <div className="col-lg-8 col-md-10 mx-auto">
                        <h1 className="fw-bold">Semua Koleksi Buku ({bookList.length} Item)</h1>
                        <p className="lead text-body-secondary">
                            Jelajahi semua buku kami di satu tempat.
                        </p>
                        <button 
                            onClick={addBook} 
                            className="btn btn-primary my-2 m-2 fw-bold shadow-sm"
                            style={{ backgroundColor: '#FF8C00', borderColor: '#FF8C00' }}
                        >
                            ➕ Tambah Buku Baru (Halaman Books)
                        </button>
                    </div>
                </div>
            </section>
            
            <div className="album py-5 bg-light">
                <div className="container">
                    <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                        {bookList.map(book => (
                            <BookCard key={book.id} book={book} />
                        ))}
                    </div>
                </div>
            </div>

            <Footer/>
        </>
    )
}