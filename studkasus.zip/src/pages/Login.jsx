import React from 'react';
import { Link } from 'react-router-dom';
import Header from "../components/shared/Header";
import Footer from "../components/shared/Footer";

export default function Login() {
  const handleLogin = (e) => {
    e.preventDefault();
    alert("Proses Login Berhasil! (Simulasi)");
  };

  return (
    <>
      <Header />
      <div className="container py-5 my-5"> 
        <div className="row justify-content-center">
          <div className="col-md-7 col-lg-5">
            <div className="card shadow-lg border-0 rounded-lg">
              
              <div className="card-header bg-primary text-white text-center py-4">
                <i className="fa-solid fa-user-lock fa-2x mb-2"></i>
                <h3 className="fw-light mt-2 mb-0">Selamat Datang Kembali</h3>
              </div>
              
              <div className="card-body p-4 p-md-5">
                <h5 className='text-center mb-4 text-secondary'>Silakan masuk untuk melanjutkan</h5>
                <form onSubmit={handleLogin}>
                  
                  <div className="form-floating mb-3">
                    <input
                      className="form-control"
                      id="inputEmail"
                      type="email"
                      placeholder="name@example.com"
                      required
                    />
                    <label htmlFor="inputEmail">Alamat Email</label>
                  </div>

                  <div className="form-floating mb-4">
                    <input
                      className="form-control"
                      id="inputPassword"
                      type="password"
                      placeholder="Password"
                      required
                    />
                    <label htmlFor="inputPassword">Password</label>
                  </div>

                  <div className="d-grid gap-2">
                    <button className="btn btn-primary btn-lg fw-bold" type="submit">
                      MASUK
                    </button>
                  </div>
                </form>
              </div>
              
              <div className="card-footer text-center py-3 bg-light">
                <div className="small">
                  Belum punya akun? <Link to="/register" className='text-decoration-none fw-bold'>Daftar Sekarang</Link>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}