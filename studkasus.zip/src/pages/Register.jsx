import React from 'react';
import { Link } from 'react-router-dom';
import Header from "../components/shared/Header";
import Footer from "../components/shared/Footer";

export default function Register() {
  const handleRegister = (e) => {
    e.preventDefault();
    alert("Proses Pendaftaran Berhasil! (Simulasi)");
  };

  return (
    <>
      <Header />
      <div className="container py-5 my-5">
        <div className="row justify-content-center">
          <div className="col-md-8 col-lg-6">
            <div className="card shadow-lg border-0 rounded-lg">
              
              <div className="card-header bg-success text-white text-center py-4">
                <i className="fa-solid fa-user-plus fa-2x mb-2"></i>
                <h3 className="fw-light mt-2 mb-0">Buat Akun Baru</h3>
              </div>
              
              <div className="card-body p-4 p-md-5">
                <h5 className='text-center mb-4 text-secondary'>Bergabung dengan Komunitas Bookstore</h5>
                <form onSubmit={handleRegister}>
                  
                  <div className="form-floating mb-3">
                    <input
                      className="form-control"
                      id="inputName"
                      type="text"
                      placeholder="Nama Lengkap"
                      required
                    />
                    <label htmlFor="inputName">Nama Lengkap</label>
                  </div>
                  
                  <div className="form-floating mb-3">
                    <input
                      className="form-control"
                      id="inputEmail"
                      type="email"
                      placeholder="name@example.com"
                      required
                    />
                    <label htmlFor="inputEmail">Alamat Email</label>
                  </div>

                  <div className="row mb-4">
                    <div className="col-md-6">
                      <div className="form-floating mb-3 mb-md-0">
                        <input
                          className="form-control"
                          id="inputPassword"
                          type="password"
                          placeholder="Buat Password"
                          required
                        />
                        <label htmlFor="inputPassword">Password</label>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-floating mb-3 mb-md-0">
                        <input
                          className="form-control"
                          id="inputPasswordConfirm"
                          type="password"
                          placeholder="Konfirmasi Password"
                          required
                        />
                        <label htmlFor="inputPasswordConfirm">Konfirmasi Password</label>
                      </div>
                    </div>
                  </div>

                  <div className="d-grid gap-2">
                    <button className="btn btn-success btn-lg fw-bold" type="submit">
                      DAFTAR SEKARANG
                    </button>
                  </div>
                </form>
              </div>
              
              <div className="card-footer text-center py-3 bg-light">
                <div className="small">
                  Sudah punya akun? <Link to="/login" className='text-decoration-none fw-bold'>Login</Link>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}