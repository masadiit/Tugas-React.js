import React, { useState } from "react";
import initialBooks from "../Utils/books";
import BookCard from "../components/shared/BookCard";

import Contact from "../components/shared/Contact";
import Footer from "../components/shared/Footer";
import Header from "../components/shared/Header";
import Hero from "../components/shared/Hero";
import Team from "../components/shared/Team";

export default function Home() {
  const [bookList, setBookList] = useState(initialBooks);

  const addBook = () => {
    const newId = Date.now();
    const newBook = {
      id: newId,
      title: `Buku Baru Tambahan (${newId % 100})`,
      author: "Mahasiswa Hooks",
      year: new Date().getFullYear(),
      description:
        "Ini adalah buku yang ditambahkan menggunakan fungsionalitas React Hooks (useState).",
      image: `https://placehold.co/300x200/FFC0CB/800080?text=NEW+BOOK+${
        newId % 100
      }`,
    };

    setBookList([newBook, ...bookList]);
  };

  return (
    <>
      <Header />
      <Hero />
      <section className="py-5 text-center container">
        <div className="row py-lg-5">
          <div className="col-lg-8 col-md-10 mx-auto">
            <h1 className="fw-bold">
              Koleksi Buku Terkini ({bookList.length} Item)
            </h1>
            <p className="lead text-body-secondary">
              Temukan buku terbaru dari penulis favorit Anda.
            </p>

            <button
              onClick={addBook}
              className="btn btn-primary my-2 m-2 fw-bold shadow-sm"
              style={{ backgroundColor: "#10B981", borderColor: "#10B981" }}
            >
              ➕ Tambah Buku Baru (Hooks/useState)
            </button>
          </div>
        </div>
      </section>
      <div className="album py-5 bg-light">
        <div className="container">
          <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            {bookList.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </div>
      <Team />
      <Contact />
      <Footer />
    </>
  );
}
